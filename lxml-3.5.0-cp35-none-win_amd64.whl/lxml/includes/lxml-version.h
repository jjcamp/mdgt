#ifndef LXML_VERSION_STRING
#define LXML_VERSION_STRING "3.5.0"
#endif
